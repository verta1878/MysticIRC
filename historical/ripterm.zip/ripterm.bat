@echo off
rem cls
rem echo Use CTRL+X when you wish to exit.
rem pause
cd ript154
ripterm -N -Rstart
exit
