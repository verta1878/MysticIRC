{ makemenu_rip.pas — Mystic BBS Menu Editor (RIP Graphics Mode)
  640x350 EGA graphical menu editor using the RIP engine stack.
  Reads theme.dat, picks theme, lists menus.
  RIP mode edits .mrp files, ANSI mode edits .mnu files (same format).

  Usage:
    makemenu_rip                    Graphics mode editor
    makemenu_rip -demo <name>       Create demo menu files
    makemenu_rip -?                 Help

  Copyright (C) 2026 FPC264IRC Contributors.
  License: GNU General Public License v3.0.
  Part of Mystic BBS, MAKEMENU, MAKETEXT.
  Credits: verta1878, sysop/0, bob, evga, kiddo, wrench,
           hexadecimal, byte, DotMatrix. }
{$MODE DELPHI}
{$H-}
Program makemenu_rip;

Uses
  SysUtils, Dos,
  {$IFDEF UNIX}CRT, ptcgraph, ptcmouse{$ELSE}Graph{$ENDIF},
  RIPEngine, RIPDraw, RIPText, RIPWidgets, RIPMouse, RIPState,
  RIPTextVar, RIPBmp, MRP_Render,
  BBS_Records, mrpdata;

Const
  VERSION = 'MAKEMENU v0.1.0 (RIP Mode) - Mystic BBS Menu Editor';

  { Colors — EGA palette }
  CLR_BG      = 1;   { dark blue background }
  CLR_TITLE   = 15;  { white title }
  CLR_MENU_BG = 7;   { light gray menu surface }
  CLR_MENU_FG = 0;   { black text }
  CLR_HILITE  = 9;   { light blue highlight }
  CLR_SHADOW  = 8;   { dark gray shadow }
  CLR_BRIGHT  = 15;  { white highlight }
  CLR_HEADER  = 3;   { cyan header row }
  CLR_SELECT  = 9;   { light blue selected row }
  CLR_WARN    = 14;  { yellow warning/info }

Var
  bbsCfg    : RecConfig;
  HasConfig : Boolean;
  Gd, Gm   : SmallInt;
  QuitNow   : Boolean;  { Alt+X / Ctrl+X global quit flag }
  EditMode  : Byte;     { 0 = RIP Menu Editor, 1 = ANSI Menu Editor }

{ ================================================================
  Config file I/O
  ================================================================ }

Function LoadConfig: Boolean;
Var F: File of RecConfig;
Begin
  Result := False;
  Assign(F, 'mystic.dat');
  {$I-} System.Reset(F); {$I+}
  If IOResult <> 0 Then Exit;
  Read(F, bbsCfg);
  Close(F);
  Result := True;
End;

{ ================================================================
  Flush canvas to screen via Graph
  ================================================================ }

Procedure FlushToScreen;
Var X, Y, RunStart: Integer;
    RunColor: Byte;
Begin
  For Y := 0 To RIP_HEIGHT - 1 Do Begin
    RunStart := 0;
    RunColor := Canvas.Pixels^[0, Y];
    For X := 1 To RIP_WIDTH - 1 Do Begin
      If Canvas.Pixels^[X, Y] <> RunColor Then Begin
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(RunColor);
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.Line(RunStart, Y, X - 1, Y);
        RunStart := X;
        RunColor := Canvas.Pixels^[X, Y];
      End;
    End;
    { final run }
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(RunColor);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.Line(RunStart, Y, RIP_WIDTH - 1, Y);
  End;
End;

{ ================================================================
  Common UI primitives
  ================================================================ }

Procedure DrawBackground;
Var Y: Integer;
Begin
  For Y := 0 To RIP_HEIGHT - 1 Do
    HLine(0, RIP_WIDTH - 1, Y, CLR_BG);
End;

Procedure DrawTitleBar;
Begin
  DrawRaisedBox(0, 0, RIP_WIDTH - 1, 28, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
  DrawTextCentered(0, 0, RIP_WIDTH - 1, 28, VERSION, CLR_MENU_FG);
End;

Procedure DrawStatusBar(Const Msg: String);
Begin
  FillRect(0, RIP_HEIGHT - 16, RIP_WIDTH - 1, RIP_HEIGHT - 1, 0);
  SetColor(11);
  OutTextXY(8, RIP_HEIGHT - 14, Msg);
End;

Procedure DrawCrewTag;
Begin
  SetColor(CLR_SHADOW);
  OutTextXY(500, RIP_HEIGHT - 14, 'the crew 4free');
End;

Procedure DrawListHeader(Y: Integer; Const Col1, Col2: String; W1: Integer);
Begin
  FillRect(10, Y, RIP_WIDTH - 10, Y + 14, CLR_HEADER);
  SetColor(CLR_MENU_FG);
  OutTextXY(16, Y + 2, Col1);
  OutTextXY(16 + W1, Y + 2, Col2);
End;

Procedure DrawListRow(Y: Integer; Const Col1, Col2: String; W1: Integer;
  Selected: Boolean);
Begin
  If Selected Then
    FillRect(10, Y, RIP_WIDTH - 10, Y + 14, CLR_SELECT)
  Else
    FillRect(10, Y, RIP_WIDTH - 10, Y + 14, CLR_BG);
  If Selected Then SetColor(CLR_WARN) Else SetColor(CLR_MENU_BG);
  OutTextXY(16, Y + 2, Col1);
  OutTextXY(16 + W1, Y + 2, Col2);
End;

{ ================================================================
  Keyboard helper — Windows: GetAsyncKeyState (works with Graph
  window regardless of focus); Unix: CRT.ReadKey
  ================================================================ }

{$IFDEF WINDOWS}
Function WinGetAsyncKeyState(vKey: LongInt): SmallInt; stdcall;
  external 'user32.dll' name 'GetAsyncKeyState';
Procedure WinSleep(dwMs: LongWord); stdcall;
  external 'kernel32.dll' name 'Sleep';
Procedure WinExitProcess(uExitCode: LongWord); stdcall;
  external 'kernel32.dll' name 'ExitProcess';

Function IsVKDown(VK: LongInt): Boolean;
Begin
  Result := WinGetAsyncKeyState(VK) < 0;  { high bit set = key down }
End;

Function GetKey(Var Ch: Char): Word;
{ Polls GetAsyncKeyState — returns scan-code Words matching
  $4800=Up, $5000=Down, $4900=PgUp, $5100=PgDn,
  $000D=Enter, $001B=ESC, etc. }
Var
  VK: LongInt;
  Shift: Boolean;
Begin
  Ch := #0;
  Result := 0;
  WinSleep(50); { debounce from previous call }
  Repeat
    WinSleep(15);
    Shift := IsVKDown($10); { VK_SHIFT }

    { Alt+X or Ctrl+X = quit }
    If (IsVKDown($12) Or IsVKDown($11)) And IsVKDown($58) Then
      Begin Result := $FFFF; Exit; End;

    { Navigation / control keys }
    If IsVKDown($26) Then Begin Result := $4800; Exit; End; { Up }
    If IsVKDown($28) Then Begin Result := $5000; Exit; End; { Down }
    If IsVKDown($21) Then Begin Result := $4900; Exit; End; { PgUp }
    If IsVKDown($22) Then Begin Result := $5100; Exit; End; { PgDn }
    If IsVKDown($0D) Then Begin Ch := #13; Result := $000D; Exit; End; { Enter }
    If IsVKDown($1B) Then Begin Ch := #27; Result := $001B; Exit; End; { ESC }
    If IsVKDown($08) Then Begin Ch := #8;  Result := $0008; Exit; End; { Backspace }
    If IsVKDown($09) Then Begin Ch := #9;  Result := $0009; Exit; End; { Tab }
    If IsVKDown($2D) Then Begin Result := $5200; Exit; End; { Insert }
    If IsVKDown($2E) Then Begin Result := $5300; Exit; End; { Delete }
    If IsVKDown($20) Then Begin Ch := ' '; Result := $0020; Exit; End; { Space }

    { Ctrl+Letter combos (before plain letters) }
    If IsVKDown($11) Then Begin { VK_CONTROL }
      If IsVKDown($49) Then Begin Result := $0109; Exit; End; { Ctrl+I }
      If IsVKDown($44) Then Begin Result := $0104; Exit; End; { Ctrl+D }
      If IsVKDown($43) Then Begin Result := $0103; Exit; End; { Ctrl+C }
      If IsVKDown($50) Then Begin Result := $0110; Exit; End; { Ctrl+P }
      If IsVKDown($56) Then Begin Result := $0116; Exit; End; { Ctrl+V }
    End;

    { Letters A-Z }
    For VK := $41 to $5A Do
      If IsVKDown(VK) Then Begin
        If Shift Then Ch := Chr(VK) Else Ch := Chr(VK + 32);
        Result := Ord(Ch); Exit;
      End;

    { Digits 0-9 }
    For VK := $30 to $39 Do
      If IsVKDown(VK) Then Begin
        If Not Shift Then Ch := Chr(VK)
        Else Case VK Of
          $30: Ch := ')'; $31: Ch := '!'; $32: Ch := '@';
          $33: Ch := '#'; $34: Ch := '$'; $35: Ch := '%';
          $36: Ch := '^'; $37: Ch := '&'; $38: Ch := '*';
          $39: Ch := '(';
        End;
        Result := Ord(Ch); Exit;
      End;

    { Common punctuation (US keyboard layout) }
    If IsVKDown($BD) Then Begin If Shift Then Ch:='_' Else Ch:='-'; Result:=Ord(Ch); Exit; End;
    If IsVKDown($BB) Then Begin If Shift Then Ch:='+' Else Ch:='='; Result:=Ord(Ch); Exit; End;
    If IsVKDown($BE) Then Begin If Shift Then Ch:='>' Else Ch:='.'; Result:=Ord(Ch); Exit; End;
    If IsVKDown($BC) Then Begin If Shift Then Ch:='<' Else Ch:=','; Result:=Ord(Ch); Exit; End;
    If IsVKDown($BF) Then Begin If Shift Then Ch:='?' Else Ch:='/'; Result:=Ord(Ch); Exit; End;
    If IsVKDown($DC) Then Begin If Shift Then Ch:='|' Else Ch:='\'; Result:=Ord(Ch); Exit; End;
    If IsVKDown($BA) Then Begin If Shift Then Ch:=':' Else Ch:=';'; Result:=Ord(Ch); Exit; End;
    If IsVKDown($DE) Then Begin If Shift Then Ch:='"' Else Ch:=#39; Result:=Ord(Ch); Exit; End;
    If IsVKDown($DB) Then Begin If Shift Then Ch:='{' Else Ch:='['; Result:=Ord(Ch); Exit; End;
    If IsVKDown($DD) Then Begin If Shift Then Ch:='}' Else Ch:=']'; Result:=Ord(Ch); Exit; End;
    If IsVKDown($C0) Then Begin If Shift Then Ch:='~' Else Ch:='`'; Result:=Ord(Ch); Exit; End;
  Until False;
End;
{$ELSE}
{ Unix: CRT.ReadKey works fine with ptcgraph }
Function GetKey(Var Ch: Char): Word;
Var C: Char;
Begin
  C := ReadKey;
  If C = #0 Then Begin
    C := ReadKey;
    Ch := #0;
    Result := Word(Ord(C)) Shl 8;
  End Else Begin
    Ch := C;
    Result := Ord(C);
  End;
End;
{$ENDIF}

{ ================================================================
  Text field editor (inline, like mconfig)
  ================================================================ }

Function EditTextField(Var Val: String; MaxLen: Integer;
  FX, FY, FW: Integer): Boolean;
Var
  Buf : String;
  Code: Word;
  Ch  : Char;
  Done: Boolean;
Begin
  Result := False;
  Buf := Val;
  Done := False;
  Repeat
    DrawSunkenBox(FX, FY-2, FW, FY+12, 1, CLR_SHADOW, CLR_BRIGHT);
    FlushToScreen;
    { Draw edit text AFTER flush so it stays visible }
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(FX + 4, FY, Buf + '_');

    Code := GetKey(Ch);

    Case Code Of
      $000D: Begin Val := Buf; Result := True; Done := True; End;
      $001B: Done := True;
      $0008: If Length(Buf) > 0 Then Delete(Buf, Length(Buf), 1);
    Else
      If (Ch >= ' ') And (Ch <= '~') And (Length(Buf) < MaxLen) Then
        Buf := Buf + Ch;
    End;
  Until Done;
End;

Function EditNumField(Var Val: LongInt; MaxLen: Integer; Lo, Hi: LongInt;
  FX, FY, FW: Integer): Boolean;
Var
  Buf : String;
  Code: Word;
  Ch  : Char;
  Done: Boolean;
  N   : LongInt;
Begin
  Result := False;
  Buf := IntToStr(Val);
  Done := False;
  Repeat
    DrawSunkenBox(FX, FY-2, FW, FY+12, 1, CLR_SHADOW, CLR_BRIGHT);
    FlushToScreen;
    { Draw edit text AFTER flush so it stays visible }
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(FX + 4, FY, Buf + '_');

    Code := GetKey(Ch);

    Case Code Of
      $000D: Begin
        N := StrToIntDef(Buf, -1);
        If (N >= Lo) And (N <= Hi) Then Begin Val := N; Result := True; End;
        Done := True;
      End;
      $001B: Done := True;
      $0008: If Length(Buf) > 0 Then Delete(Buf, Length(Buf), 1);
    Else
      If (Ch >= '0') And (Ch <= '9') And (Length(Buf) < MaxLen) Then
        Buf := Buf + Ch;
    End;
  Until Done;
End;

{ ================================================================
  Message box (modal overlay)
  ================================================================ }

Procedure MessageBox(Const Title, Msg: String);
Var Dummy: Char;
Begin
  DrawRaisedBox(100, 120, 540, 220, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
  SetColor(CLR_MENU_FG);
  OutTextXY(110, 130, Title);
  DrawSeparatorH(105, 535, 144, CLR_BRIGHT, CLR_SHADOW);
  OutTextXY(110, 155, Msg);
  SetColor(CLR_SHADOW);
  OutTextXY(110, 200, 'Press any key...');
  FlushToScreen;
  GetKey(Dummy);
End;

Function ConfirmBox(Const Title, Msg: String): Boolean;
Var
  Ch  : Char;
Begin
  Result := False;
  DrawRaisedBox(100, 120, 540, 220, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
  SetColor(CLR_MENU_FG);
  OutTextXY(110, 130, Title);
  DrawSeparatorH(105, 535, 144, CLR_BRIGHT, CLR_SHADOW);
  OutTextXY(110, 155, Msg);
  SetColor(CLR_WARN);
  OutTextXY(110, 200, 'Y=Yes  N/ESC=No');
  FlushToScreen;

  GetKey(Ch);
  Result := (Ch = 'Y') Or (Ch = 'y');
End;

{ ================================================================
  Screen 1: Theme Selector
  ================================================================ }

Const
  MAX_THEMES = 32;

Var
  Themes     : Array[0..MAX_THEMES-1] of RecTheme;
  ThemeCount : Integer;

Function LoadThemes: Boolean;
Var
  F: File of RecTheme;
  ThemePath: String;
Begin
  Result := False;
  ThemeCount := 0;
  ThemePath := bbsCfg.DataPath + 'theme.dat';
  Assign(F, ThemePath);
  {$I-} System.Reset(F); {$I+}
  If IOResult <> 0 Then Exit;
  While Not Eof(F) And (ThemeCount < MAX_THEMES) Do Begin
    Read(F, Themes[ThemeCount]);
    Inc(ThemeCount);
  End;
  Close(F);
  Result := ThemeCount > 0;
End;

Procedure DrawThemePage(Selection: Integer; PageOfs: Integer);
Var
  I, Y, VisCount, Idx: Integer;
Begin
  DrawBackground;
  DrawTitleBar;

  { Content box }
  DrawRaisedBox(5, 35, RIP_WIDTH - 6, RIP_HEIGHT - 20, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
  SetColor(CLR_MENU_FG);
  OutTextXY(12, 40, 'Select Theme');
  DrawSeparatorH(10, RIP_WIDTH - 10, 52, CLR_BRIGHT, CLR_SHADOW);

  { Column header }
  DrawListHeader(56, '  #  File Name', 'Description', 180);

  { Visible rows }
  VisCount := 14;  { rows that fit in the box }
  Y := 72;
  For I := 0 to VisCount - 1 Do Begin
    Idx := PageOfs + I;
    If Idx < ThemeCount Then Begin
      DrawListRow(Y, '  ' + IntToStr(Idx + 1) + '  ' + Themes[Idx].FileName,
                  Themes[Idx].Desc, 180, Idx = Selection);
    End Else
      FillRect(10, Y, RIP_WIDTH - 10, Y + 14, CLR_BG);
    Y := Y + 16;
  End;

  { Shadow }
  FillRect(RIP_WIDTH - 8, 60, RIP_WIDTH - 4, Y, 0);
  FillRect(12, Y, RIP_WIDTH - 4, Y + 4, 0);

  { Footer }
  SetColor(CLR_MENU_FG);
  OutTextXY(12, RIP_HEIGHT - 34, IntToStr(ThemeCount) + ' themes in ' +
            bbsCfg.DataPath + 'theme.dat');

  DrawStatusBar('Up/Down=Move  ENTER=Select  ESC=Exit');
  DrawCrewTag;
  FlushToScreen;
End;

{ ================================================================
  Mode selector — RIP or ANSI menu editing
  ================================================================ }

Procedure DrawModeSelector(Sel: Integer);
Begin
  DrawBackground;
  DrawTitleBar;
  DrawSeparatorH(10, RIP_WIDTH - 10, 34, CLR_BRIGHT, CLR_SHADOW);

  { Two options }
  DrawListRow(60, 'RIP Menu Editor', 'Graphical RIP button menus (.mrp)', 200, Sel = 0);
  DrawListRow(76, 'ANSI Menu Editor', 'Text/ANSI pipe-code menus (.mnu)', 200, Sel = 1);

  DrawStatusBar('Up/Down=Move  ENTER=Select  ESC=Exit');
  DrawCrewTag;
  FlushToScreen;
End;

Function RunModeSelector: Integer;
{ Returns 0 = RIP, 1 = ANSI, -1 = cancelled }
Var
  Sel     : Integer;
  Running : Boolean;
  Code    : Word;
  Ch      : Char;
Begin
  Result := -1;
  Sel := 0;
  Running := True;
  DrawModeSelector(Sel);

  While Running Do Begin
    Code := GetKey(Ch);
    Case Code Of
      $4800: Begin If Sel > 0 Then Dec(Sel); DrawModeSelector(Sel); End;
      $5000: Begin If Sel < 1 Then Inc(Sel); DrawModeSelector(Sel); End;
      $000D: Begin Result := Sel; Running := False; End;
      $001B: Running := False;
      $FFFF: Begin QuitNow := True; Running := False; End;
    End;
  End;
End;

Function RunThemeSelector: Integer;
{ Returns 0-based theme index, or -1 if cancelled }
Var
  Sel, PageOfs, VisCount: Integer;
  Running: Boolean;
  Code: Word;
  Ch: Char;
Begin
  Result := -1;
  If Not LoadThemes Then Begin
    MessageBox('Error', 'No themes in ' + bbsCfg.DataPath + 'theme.dat');
    Exit;
  End;

  Sel := 0;
  PageOfs := 0;
  VisCount := 14;
  Running := True;
  DrawThemePage(Sel, PageOfs);

  While Running Do Begin
    Code := GetKey(Ch);

    Case Code Of
      $4800: Begin { Up }
        If Sel > 0 Then Begin
          Dec(Sel);
          If Sel < PageOfs Then PageOfs := Sel;
        End;
        DrawThemePage(Sel, PageOfs);
      End;
      $5000: Begin { Down }
        If Sel < ThemeCount - 1 Then Begin
          Inc(Sel);
          If Sel >= PageOfs + VisCount Then PageOfs := Sel - VisCount + 1;
        End;
        DrawThemePage(Sel, PageOfs);
      End;
      $4900: Begin { PgUp }
        Dec(Sel, VisCount);
        If Sel < 0 Then Sel := 0;
        PageOfs := Sel;
        DrawThemePage(Sel, PageOfs);
      End;
      $5100: Begin { PgDn }
        Inc(Sel, VisCount);
        If Sel >= ThemeCount Then Sel := ThemeCount - 1;
        If Sel >= PageOfs + VisCount Then PageOfs := Sel - VisCount + 1;
        DrawThemePage(Sel, PageOfs);
      End;
      $000D: Begin { Enter }
        Result := Sel;
        Running := False;
      End;
      $001B: Running := False; { ESC }
      $FFFF: Begin QuitNow := True; Running := False; End; { Alt+X }
    End;
  End;
End;

{ ================================================================
  Screen 2: Menu List
  ================================================================ }

Const
  MAX_MENUS = 75;

Type
  TMenuEntry = Record
    Name : String[40];
    Desc : String[60];
  End;

Var
  MenuList  : Array[0..MAX_MENUS-1] of TMenuEntry;
  MenuCount : Integer;

Procedure ScanMenus(Const MenuPath: String);
Var
  SR: SearchRec;
  Menu: TMenuData;
Begin
  MenuCount := 0;
  If EditMode = 0 Then
    FindFirst(MenuPath + '*.mrp', Archive, SR)
  Else
    FindFirst(MenuPath + '*.mnu', Archive, SR);
  While (DosError = 0) And (MenuCount < MAX_MENUS) Do Begin
    MenuList[MenuCount].Name := ChangeFileExt(SR.Name, '');

    { Try to read description from .mnu header }
    Menu := TMenuData.Create;
    If Menu.LoadMnu(MenuPath + SR.Name) Then
      MenuList[MenuCount].Desc := Menu.Info.Description
    Else
      MenuList[MenuCount].Desc := '(cannot read)';
    Menu.Free;

    Inc(MenuCount);
    FindNext(SR);
  End;
  FindClose(SR);
End;

Procedure DrawMenuListPage(Selection, PageOfs: Integer; Const MenuPath: String);
Var
  I, Y, VisCount, Idx: Integer;
Begin
  DrawBackground;
  DrawTitleBar;

  DrawRaisedBox(5, 35, RIP_WIDTH - 6, RIP_HEIGHT - 20, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
  SetColor(CLR_MENU_FG);
  OutTextXY(12, 40, 'Menu Editor - ' + MenuPath);
  DrawSeparatorH(10, RIP_WIDTH - 10, 52, CLR_BRIGHT, CLR_SHADOW);

  DrawListHeader(56, '  Menu Name', 'Description', 180);

  VisCount := 14;
  Y := 72;
  For I := 0 to VisCount - 1 Do Begin
    Idx := PageOfs + I;
    If Idx < MenuCount Then
      DrawListRow(Y, '  ' + MenuList[Idx].Name, MenuList[Idx].Desc, 180, Idx = Selection)
    Else
      FillRect(10, Y, RIP_WIDTH - 10, Y + 14, CLR_BG);
    Y := Y + 16;
  End;

  FillRect(RIP_WIDTH - 8, 60, RIP_WIDTH - 4, Y, 0);
  FillRect(12, Y, RIP_WIDTH - 4, Y + 4, 0);

  SetColor(CLR_MENU_FG);
  OutTextXY(12, RIP_HEIGHT - 34, IntToStr(MenuCount) + ' menus in ' + MenuPath);

  DrawStatusBar('Up/Dn=Move  ENTER=Edit  /=Commands  Ctrl+IDCP  ESC=Back');
  DrawCrewTag;
  FlushToScreen;
End;

Function RunMenuList(Const MenuPath: String): String;
{ Returns menu name (without extension), or '' if cancelled }
Var
  Sel, PageOfs, VisCount: Integer;
  Running: Boolean;
  Code: Word;
  Ch: Char;
Begin
  Result := '';
  ScanMenus(MenuPath);

  Sel := 0;
  PageOfs := 0;
  VisCount := 14;
  Running := True;
  DrawMenuListPage(Sel, PageOfs, MenuPath);

  While Running Do Begin
    Code := GetKey(Ch);

    Case Code Of
      $4800: Begin { Up }
        If Sel > 0 Then Begin
          Dec(Sel);
          If Sel < PageOfs Then PageOfs := Sel;
        End;
        DrawMenuListPage(Sel, PageOfs, MenuPath);
      End;
      $5000: Begin { Down }
        If Sel < MenuCount - 1 Then Begin
          Inc(Sel);
          If Sel >= PageOfs + VisCount Then PageOfs := Sel - VisCount + 1;
        End;
        DrawMenuListPage(Sel, PageOfs, MenuPath);
      End;
      $4900: Begin { PgUp }
        Dec(Sel, VisCount);
        If Sel < 0 Then Sel := 0;
        PageOfs := Sel;
        DrawMenuListPage(Sel, PageOfs, MenuPath);
      End;
      $5100: Begin { PgDn }
        Inc(Sel, VisCount);
        If Sel >= MenuCount Then Sel := MenuCount - 1;
        If Sel >= PageOfs + VisCount Then PageOfs := Sel - VisCount + 1;
        DrawMenuListPage(Sel, PageOfs, MenuPath);
      End;
      $000D: Begin { Enter }
        If MenuCount > 0 Then Begin
          Result := MenuList[Sel].Name;
          Running := False;
        End;
      End;
      $001B: Running := False; { ESC }
      $FFFF: Begin QuitNow := True; Running := False; End; { Alt+X }
    End;
  End;
End;

{ ================================================================
  Screen 3: Menu Item Editor
  ================================================================ }

Procedure DrawMenuEditor(Menu: TMenuData; CurItem, PageOfs: Integer;
  Const MenuName: String);
Var
  I, Y, VisCount, Idx: Integer;
Begin
  DrawBackground;
  DrawTitleBar;

  { Main content box }
  DrawRaisedBox(5, 35, RIP_WIDTH - 6, RIP_HEIGHT - 20, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
  SetColor(CLR_MENU_FG);
  If EditMode = 0 Then
    OutTextXY(12, 40, 'Editing: ' + MenuName + '.mrp - ' + Menu.Info.Description)
  Else
    OutTextXY(12, 40, 'Editing: ' + MenuName + '.mnu - ' + Menu.Info.Description);
  DrawSeparatorH(10, RIP_WIDTH - 10, 52, CLR_BRIGHT, CLR_SHADOW);

  { Column header }
  FillRect(10, 56, RIP_WIDTH - 10, 70, CLR_HEADER);
  SetColor(CLR_MENU_FG);
  OutTextXY(16, 58, ' #');
  OutTextXY(40, 58, 'Key');
  OutTextXY(80, 58, 'Text');
  OutTextXY(320, 58, 'Cmd');
  OutTextXY(370, 58, 'Data');
  OutTextXY(530, 58, 'X,Y');

  { Visible item rows }
  VisCount := 12;
  Y := 72;
  For I := 0 to VisCount - 1 Do Begin
    Idx := PageOfs + I + 1; { items are 1-based }
    If (Idx >= 1) And (Idx <= Menu.NumItems) And (Menu.Item[Idx] <> Nil) Then Begin
      If Idx = CurItem Then
        FillRect(10, Y, RIP_WIDTH - 10, Y + 14, CLR_SELECT)
      Else
        FillRect(10, Y, RIP_WIDTH - 10, Y + 14, CLR_BG);

      If Idx = CurItem Then SetColor(CLR_WARN) Else SetColor(CLR_MENU_BG);
      OutTextXY(16, Y + 2, IntToStr(Idx));
      OutTextXY(40, Y + 2, Copy(Menu.Item[Idx]^.HotKey, 1, 4));
      OutTextXY(80, Y + 2, Copy(Menu.Item[Idx]^.Text, 1, 28));

      { First command }
      If (Menu.Item[Idx]^.Commands > 0) And (Menu.Item[Idx]^.CmdData[1] <> Nil) Then Begin
        OutTextXY(320, Y + 2, Copy(Menu.Item[Idx]^.CmdData[1]^.MenuCmd, 1, 4));
        OutTextXY(370, Y + 2, Copy(Menu.Item[Idx]^.CmdData[1]^.Data, 1, 18));
      End;

      OutTextXY(530, Y + 2, IntToStr(Menu.Item[Idx]^.X) + ',' +
                IntToStr(Menu.Item[Idx]^.Y));
    End Else
      FillRect(10, Y, RIP_WIDTH - 10, Y + 14, CLR_BG);
    Y := Y + 16;
  End;

  { Shadow }
  FillRect(RIP_WIDTH - 8, 60, RIP_WIDTH - 4, Y, 0);
  FillRect(12, Y, RIP_WIDTH - 4, Y + 4, 0);

  { Footer info }
  DrawSeparatorH(10, RIP_WIDTH - 10, Y + 8, CLR_BRIGHT, CLR_SHADOW);
  SetColor(CLR_MENU_FG);
  OutTextXY(12, Y + 12, IntToStr(Menu.NumItems) + ' items');
  If (CurItem >= 1) And (CurItem <= Menu.NumItems) And (Menu.Item[CurItem] <> Nil) Then Begin
    OutTextXY(100, Y + 12, 'Jumps: U=' + IntToStr(Menu.Item[CurItem]^.JumpUp) +
              ' D=' + IntToStr(Menu.Item[CurItem]^.JumpDown) +
              ' L=' + IntToStr(Menu.Item[CurItem]^.JumpLeft) +
              ' R=' + IntToStr(Menu.Item[CurItem]^.JumpRight));
    OutTextXY(450, Y + 12, 'Cmds: ' + IntToStr(Menu.Item[CurItem]^.Commands));
  End;

  DrawStatusBar('/I-Insert  /D-Delete  /C-Copy  /P-Paste  ENTER-Edit  ESC-Save+Back');
  DrawCrewTag;
  FlushToScreen;
End;

{ ================================================================
  Screen 4: Item Detail Editor (overlay)
  ================================================================ }

Procedure DrawItemDetail(Menu: TMenuData; Idx: Integer; CurField: Integer);
Var
  I, Y: Integer;

  Procedure FieldBox(FX, FY, FW, FIdx: Integer);
  Begin
    If CurField = FIdx Then
      DrawSunkenBox(FX, FY-2, FW, FY+12, 4, CLR_SHADOW, CLR_BRIGHT)
    Else
      DrawSunkenBox(FX, FY-2, FW, FY+12, 7, CLR_SHADOW, CLR_BRIGHT);
  End;

Begin
  { === PASS 1: Draw all canvas (RIP) elements === }
  DrawRaisedBox(30, 40, RIP_WIDTH - 30, RIP_HEIGHT - 30, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
  DrawSeparatorH(35, RIP_WIDTH - 35, 58, CLR_BRIGHT, CLR_SHADOW);

  Y := 64;
  FieldBox(120, Y, 580, 0);  Y := Y + 20; { Text }
  FieldBox(120, Y, 580, 1);  Y := Y + 20; { TextLo }
  FieldBox(120, Y, 580, 2);  Y := Y + 20; { TextHi }
  FieldBox(120, Y, 250, 3);                { HotKey }
  FieldBox(340, Y, 580, 4);  Y := Y + 20; { Access }
  FieldBox(120, Y, 200, 5);                { X }
  FieldBox(240, Y, 320, 6);  Y := Y + 20; { Y }
  FieldBox(120, Y, 180, 7);                { JumpUp }
  FieldBox(230, Y, 290, 8);                { Dn }
  FieldBox(340, Y, 400, 9);                { Lt }
  FieldBox(450, Y, 510, 10); Y := Y + 20; { Rt }
  FieldBox(120, Y, 180, 11);               { Esc }
  FieldBox(230, Y, 290, 12);               { Tab }
  FieldBox(350, Y, 410, 13);               { PgU }
  FieldBox(460, Y, 520, 14); Y := Y + 20; { PgD }
  DrawSeparatorH(35, RIP_WIDTH - 35, Y, CLR_BRIGHT, CLR_SHADOW);

  DrawStatusBar('Up/Dn=Move  ENTER=Edit  ESC=Back');

  { === Flush canvas to screen === }
  FlushToScreen;

  { === PASS 2: Draw all text on Graph window AFTER flush === }
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(40, 46, 'Item ' + IntToStr(Idx) + ' Detail');

  Y := 64;

  { Field 0: Text }
  If CurField = 0 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(40, Y, 'Text:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(124, Y, Menu.Item[Idx]^.Text);
  Y := Y + 20;

  { Field 1: TextLo }
  If CurField = 1 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(40, Y, 'TextLo:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(124, Y, Menu.Item[Idx]^.TextLo);
  Y := Y + 20;

  { Field 2: TextHi }
  If CurField = 2 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(40, Y, 'TextHi:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(124, Y, Menu.Item[Idx]^.TextHi);
  Y := Y + 20;

  { Field 3: HotKey }
  If CurField = 3 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(40, Y, 'HotKey:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(124, Y, Menu.Item[Idx]^.HotKey);
  { Field 4: Access }
  If CurField = 4 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(280, Y, 'Access:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(344, Y, Menu.Item[Idx]^.Access);
  Y := Y + 20;

  { Field 5: X }
  If CurField = 5 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(40, Y, 'X:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(124, Y, IntToStr(Menu.Item[Idx]^.X));
  { Field 6: Y }
  If CurField = 6 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(220, Y, 'Y:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(244, Y, IntToStr(Menu.Item[Idx]^.Y));
  Y := Y + 20;

  { Fields 7-10: Jump directions }
  If CurField = 7 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(40, Y, 'JumpUp:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(124, Y, IntToStr(Menu.Item[Idx]^.JumpUp));
  If CurField = 8 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(200, Y, 'Dn:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(234, Y, IntToStr(Menu.Item[Idx]^.JumpDown));
  If CurField = 9 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(310, Y, 'Lt:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(344, Y, IntToStr(Menu.Item[Idx]^.JumpLeft));
  If CurField = 10 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(420, Y, 'Rt:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(454, Y, IntToStr(Menu.Item[Idx]^.JumpRight));
  Y := Y + 20;

  { Fields 11-14: More jumps }
  If CurField = 11 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(40, Y, 'Esc:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(124, Y, IntToStr(Menu.Item[Idx]^.JumpEscape));
  If CurField = 12 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(200, Y, 'Tab:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(234, Y, IntToStr(Menu.Item[Idx]^.JumpTab));
  If CurField = 13 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(310, Y, 'PgU:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(354, Y, IntToStr(Menu.Item[Idx]^.JumpPgUp));
  If CurField = 14 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(420, Y, 'PgD:');
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(464, Y, IntToStr(Menu.Item[Idx]^.JumpPgDn));
  Y := Y + 20;

  { Commands header }
  Y := Y + 4;
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
  {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(40, Y, 'Commands: ' + IntToStr(Menu.Item[Idx]^.Commands) +
    '  (INS=Add  DEL=Remove)');
  Y := Y + 16;

  For I := 1 to Menu.Item[Idx]^.Commands Do Begin
    If Menu.Item[Idx]^.CmdData[I] <> Nil Then Begin
      If CurField = 15 + I - 1 Then
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) { yellow = selected cmd }
      Else
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15); { white = normal cmd }
      {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(50, Y, IntToStr(I) + ': ' +
                Menu.Item[Idx]^.CmdData[I]^.MenuCmd + ' -> ' +
                Menu.Item[Idx]^.CmdData[I]^.Data);
      If Menu.Item[Idx]^.CmdData[I]^.Access <> '' Then Begin
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(3); { cyan for access }
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(450, Y, '[' + Menu.Item[Idx]^.CmdData[I]^.Access + ']');
      End;
      Y := Y + 14;
    End;
    If Y > RIP_HEIGHT - 50 Then Break;
  End;

  { If cursor is past last command (on the "new" slot), show add hint }
  If (CurField >= 15) And (CurField - 15 >= Menu.Item[Idx]^.Commands) Then Begin
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(50, Y, '> Press INS or ENTER to add command');
  End;
End;

{ ================================================================
  Mystic Menu Command Picker
  ================================================================ }
Const
  MAX_MCMDS = 60;

Type
  TMCmdEntry = Record
    Code : String[2];
    Desc : String[40];
  End;

Const
  MCmdList : Array[1..MAX_MCMDS] of TMCmdEntry = (
    (Code:'GE'; Desc:'Go to Menu Editor'),
    (Code:'GO'; Desc:'Go to Menu'),
    (Code:'GR'; Desc:'Gosub Return'),
    (Code:'GS'; Desc:'Gosub Menu'),
    (Code:'GT'; Desc:'Go to Menu (Top)'),
    (Code:'GX'; Desc:'Exit Menu System'),
    (Code:'MA'; Desc:'Message Area Change'),
    (Code:'MC'; Desc:'Message Check New'),
    (Code:'MD'; Desc:'Message Delete'),
    (Code:'ME'; Desc:'Message Set Area #'),
    (Code:'MG'; Desc:'Message Global Search'),
    (Code:'ML'; Desc:'Message List'),
    (Code:'MM'; Desc:'Message Move'),
    (Code:'MN'; Desc:'Message New Scan'),
    (Code:'MP'; Desc:'Message Post'),
    (Code:'MR'; Desc:'Message Read'),
    (Code:'MS'; Desc:'Message Search'),
    (Code:'MW'; Desc:'Message Write'),
    (Code:'FA'; Desc:'File Area Change'),
    (Code:'FD'; Desc:'File Directory Listing'),
    (Code:'FE'; Desc:'File Set Area #'),
    (Code:'FG'; Desc:'File Group Change'),
    (Code:'FL'; Desc:'File List'),
    (Code:'FN'; Desc:'File New Scan'),
    (Code:'FP'; Desc:'File Post/Upload'),
    (Code:'FS'; Desc:'File Search'),
    (Code:'FV'; Desc:'File View Archive'),
    (Code:'FZ'; Desc:'File Download'),
    (Code:'D1'; Desc:'Display File'),
    (Code:'D2'; Desc:'Display File Once'),
    (Code:'D3'; Desc:'Display File (Pause)'),
    (Code:'DA'; Desc:'Display ANSI'),
    (Code:'DD'; Desc:'Display File Direct'),
    (Code:'DI'; Desc:'Display Information'),
    (Code:'IN'; Desc:'Input'),
    (Code:'PR'; Desc:'Prompt'),
    (Code:'SS'; Desc:'Sysop Shell'),
    (Code:'TF'; Desc:'Toggle Flag'),
    (Code:'BA'; Desc:'Bulletin Area'),
    (Code:'CB'; Desc:'Chat BBS'),
    (Code:'CT'; Desc:'Chat Teleconference'),
    (Code:'DO'; Desc:'Door/External Program'),
    (Code:'DT'; Desc:'Door (Type)'),
    (Code:'NA'; Desc:'Node Activity'),
    (Code:'OS'; Desc:'Online Users'),
    (Code:'PA'; Desc:'Page Sysop'),
    (Code:'PI'; Desc:'Page User'),
    (Code:'QA'; Desc:'Questionnaire'),
    (Code:'TL'; Desc:'Time Left'),
    (Code:'TP'; Desc:'Top Users'),
    (Code:'UE'; Desc:'User Edit (Self)'),
    (Code:'UL'; Desc:'User List'),
    (Code:'VF'; Desc:'Voting Booth'),
    (Code:'WM'; Desc:'Who Is Online'),
    (Code:'XA'; Desc:'Execute ANSI'),
    (Code:'-S'; Desc:'Stuff Keyboard'),
    (Code:'-P'; Desc:'Pause'),
    (Code:'-N'; Desc:'Newline'),
    (Code:'-C'; Desc:'Clear Screen'),
    (Code:'-X'; Desc:'Custom String Data')
  );

Function RunCommandPicker: String;
{ Full-screen scrollable list of Mystic menu commands.
  Returns 2-char code or '' if cancelled. }
Var
  Sel, Top, I, Y : Integer;
  Code           : Word;
  Ch             : Char;
  MaxVis         : Integer;
Begin
  Result := '';
  Sel := 1;
  Top := 1;
  MaxVis := 18; { how many rows fit in the picker box }

  Repeat
    { Draw picker overlay }
    DrawRaisedBox(60, 30, 580, RIP_HEIGHT - 20, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
    DrawSeparatorH(65, 575, 48, CLR_BRIGHT, CLR_SHADOW);
    DrawStatusBar('Up/Dn=Select  ENTER=Pick  ESC=Cancel');
    FlushToScreen;

    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(70, 36, 'Select Menu Command:');

    Y := 54;
    For I := Top to MAX_MCMDS Do Begin
      If I - Top >= MaxVis Then Break;
      If I = Sel Then
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) { yellow highlight }
      Else
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
      {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(80, Y, MCmdList[I].Code + '  ' + MCmdList[I].Desc);
      Y := Y + 16;
    End;

    Code := GetKey(Ch);
    Case Code Of
      $4800: If Sel > 1 Then Begin
               Dec(Sel);
               If Sel < Top Then Top := Sel;
             End;
      $5000: If Sel < MAX_MCMDS Then Begin
               Inc(Sel);
               If Sel >= Top + MaxVis Then Top := Sel - MaxVis + 1;
             End;
      $4900: Begin { PgUp }
               Dec(Sel, MaxVis);
               If Sel < 1 Then Sel := 1;
               Top := Sel;
             End;
      $5100: Begin { PgDn }
               Inc(Sel, MaxVis);
               If Sel > MAX_MCMDS Then Sel := MAX_MCMDS;
               If Sel >= Top + MaxVis Then Top := Sel - MaxVis + 1;
             End;
      $000D: Begin Result := MCmdList[Sel].Code; Exit; End;
      $001B: Exit;
      $FFFF: Begin QuitNow := True; Exit; End;
    End;
  Until False;
End;

Procedure RunEditCommand(Var Cmd: RecMenuCmd);
{ Edit a single command's fields: MenuCmd (via picker), Data, Access }
Var
  CmdField : Integer;
  Running  : Boolean;
  Code     : Word;
  Ch       : Char;
  S        : String;
  N        : LongInt;
  CY       : Integer;
Begin
  CmdField := 0;
  Running := True;

  While Running Do Begin
    DrawRaisedBox(60, 80, 580, 230, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
    DrawSeparatorH(65, 575, 98, CLR_BRIGHT, CLR_SHADOW);
    { field boxes on canvas }
    CY := 106;
    If CmdField = 0 Then
      DrawSunkenBox(150, CY-2, 220, CY+12, 4, CLR_SHADOW, CLR_BRIGHT)
    Else
      DrawSunkenBox(150, CY-2, 220, CY+12, 7, CLR_SHADOW, CLR_BRIGHT);
    CY := CY + 20;
    If CmdField = 1 Then
      DrawSunkenBox(150, CY-2, 560, CY+12, 4, CLR_SHADOW, CLR_BRIGHT)
    Else
      DrawSunkenBox(150, CY-2, 560, CY+12, 7, CLR_SHADOW, CLR_BRIGHT);
    CY := CY + 20;
    If CmdField = 2 Then
      DrawSunkenBox(150, CY-2, 400, CY+12, 4, CLR_SHADOW, CLR_BRIGHT)
    Else
      DrawSunkenBox(150, CY-2, 400, CY+12, 7, CLR_SHADOW, CLR_BRIGHT);
    CY := CY + 20;
    If CmdField = 3 Then
      DrawSunkenBox(150, CY-2, 220, CY+12, 4, CLR_SHADOW, CLR_BRIGHT)
    Else
      DrawSunkenBox(150, CY-2, 220, CY+12, 7, CLR_SHADOW, CLR_BRIGHT);
    DrawStatusBar('Up/Dn=Move  ENTER=Edit  ESC=Done');
    FlushToScreen;

    { text labels + values }
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(70, 86, 'Edit Command');
    CY := 106;
    If CmdField = 0 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(70, CY, 'Command:');
    If CmdField = 0 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(154, CY, Cmd.MenuCmd);
    CY := CY + 20;
    If CmdField = 1 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(70, CY, 'Data:');
    If CmdField = 1 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(154, CY, Cmd.Data);
    CY := CY + 20;
    If CmdField = 2 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(70, CY, 'Access:');
    If CmdField = 2 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(154, CY, Cmd.Access);
    CY := CY + 20;
    If CmdField = 3 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(70, CY, 'JumpID:');
    If CmdField = 3 Then {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(14) Else {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(154, CY, IntToStr(Cmd.JumpID));

    Code := GetKey(Ch);
    Case Code Of
      $4800: If CmdField > 0 Then Dec(CmdField);
      $5000: If CmdField < 3 Then Inc(CmdField);
      $0009: If CmdField < 3 Then Inc(CmdField) Else CmdField := 0;
      $000D: Begin
        Case CmdField Of
          0: Begin { Command picker }
            S := RunCommandPicker;
            If S <> '' Then Cmd.MenuCmd := S;
          End;
          1: Begin S := Cmd.Data;   If EditTextField(S, 160, 150, 126, 560) Then Cmd.Data := S; End;
          2: Begin S := Cmd.Access; If EditTextField(S, 30, 150, 146, 400)  Then Cmd.Access := S; End;
          3: Begin N := Cmd.JumpID; If EditNumField(N, 3, 0, 255, 150, 166, 220) Then Cmd.JumpID := N; End;
        End;
      End;
      $001B: Running := False;
      $FFFF: Begin QuitNow := True; Running := False; End;
    End;
  End;
End;

Const
  DETAIL_FIELDS = 15; { 0=Text,1=TextLo,2=TextHi,3=HotKey,4=Access,5=X,6=Y,
                         7-10=JumpUDLR,11=Esc,12=Tab,13=PgU,14=PgD;
                         15+ = command rows (15=cmd1, 16=cmd2, ...) }

Procedure RunItemDetail(Menu: TMenuData; Idx: Integer);
Var
  CurField : Integer;
  MaxField : Integer;
  Running  : Boolean;
  Code     : Word;
  Ch       : Char;
  S        : String;
  N        : LongInt;
  CmdIdx   : Integer;
Begin
  If (Idx < 1) Or (Idx > Menu.NumItems) Or (Menu.Item[Idx] = Nil) Then Exit;

  CurField := 0;
  Running := True;

  While Running Do Begin
    { Max field = 14 (last jump field) + number of commands + 1 (add slot) }
    MaxField := DETAIL_FIELDS - 1 + Menu.Item[Idx]^.Commands;
    If CurField > MaxField Then CurField := MaxField;
    DrawItemDetail(Menu, Idx, CurField);

    Code := GetKey(Ch);

    Case Code Of
      $4800: Begin { Up }
        If CurField > 0 Then Dec(CurField);
      End;
      $5000: Begin { Down }
        If CurField < MaxField Then Inc(CurField);
      End;
      $000D: Begin { Enter — edit field }
        If CurField < DETAIL_FIELDS Then Begin
          Case CurField Of
            0: Begin S := Menu.Item[Idx]^.Text;    If EditTextField(S, 60, 120, 64, 580)   Then Menu.Item[Idx]^.Text := S; End;
            1: Begin S := Menu.Item[Idx]^.TextLo;  If EditTextField(S, 60, 120, 84, 580)   Then Menu.Item[Idx]^.TextLo := S; End;
            2: Begin S := Menu.Item[Idx]^.TextHi;  If EditTextField(S, 60, 120, 104, 580)  Then Menu.Item[Idx]^.TextHi := S; End;
            3: Begin S := Menu.Item[Idx]^.HotKey;  If EditTextField(S, 10, 120, 124, 250)  Then Menu.Item[Idx]^.HotKey := S; End;
            4: Begin S := Menu.Item[Idx]^.Access;  If EditTextField(S, 30, 340, 124, 580)  Then Menu.Item[Idx]^.Access := S; End;
            5: Begin N := Menu.Item[Idx]^.X;       If EditNumField(N, 3, 0, 255, 120, 144, 200) Then Menu.Item[Idx]^.X := N; End;
            6: Begin N := Menu.Item[Idx]^.Y;       If EditNumField(N, 3, 0, 255, 240, 144, 320) Then Menu.Item[Idx]^.Y := N; End;
            7: Begin N := Menu.Item[Idx]^.JumpUp;      If EditNumField(N, 3, 0, 75, 120, 164, 180) Then Menu.Item[Idx]^.JumpUp := N; End;
            8: Begin N := Menu.Item[Idx]^.JumpDown;    If EditNumField(N, 3, 0, 75, 230, 164, 290) Then Menu.Item[Idx]^.JumpDown := N; End;
            9: Begin N := Menu.Item[Idx]^.JumpLeft;    If EditNumField(N, 3, 0, 75, 340, 164, 400) Then Menu.Item[Idx]^.JumpLeft := N; End;
            10: Begin N := Menu.Item[Idx]^.JumpRight;  If EditNumField(N, 3, 0, 75, 450, 164, 510) Then Menu.Item[Idx]^.JumpRight := N; End;
            11: Begin N := Menu.Item[Idx]^.JumpEscape;  If EditNumField(N, 3, 0, 75, 120, 184, 180) Then Menu.Item[Idx]^.JumpEscape := N; End;
            12: Begin N := Menu.Item[Idx]^.JumpTab;     If EditNumField(N, 3, 0, 75, 230, 184, 290) Then Menu.Item[Idx]^.JumpTab := N; End;
            13: Begin N := Menu.Item[Idx]^.JumpPgUp;    If EditNumField(N, 3, 0, 75, 350, 184, 410) Then Menu.Item[Idx]^.JumpPgUp := N; End;
            14: Begin N := Menu.Item[Idx]^.JumpPgDn;    If EditNumField(N, 3, 0, 75, 460, 184, 520) Then Menu.Item[Idx]^.JumpPgDn := N; End;
          End;
        End Else Begin
          { Command row — Enter edits existing or adds new }
          CmdIdx := CurField - DETAIL_FIELDS + 1; { 1-based command index }
          If (CmdIdx >= 1) And (CmdIdx <= Menu.Item[Idx]^.Commands) And
             (Menu.Item[Idx]^.CmdData[CmdIdx] <> Nil) Then
            RunEditCommand(Menu.Item[Idx]^.CmdData[CmdIdx]^)
          Else If CmdIdx = Menu.Item[Idx]^.Commands + 1 Then Begin
            { Add new command at end }
            If Menu.Item[Idx]^.Commands < MaxMenuCmds Then Begin
              Menu.InsertCommand(Idx, Menu.Item[Idx]^.Commands + 1);
              S := RunCommandPicker;
              If S <> '' Then
                Menu.Item[Idx]^.CmdData[Menu.Item[Idx]^.Commands]^.MenuCmd := S
              Else Begin
                { Cancelled — remove the command we just added }
                Menu.DeleteCommand(Idx, Menu.Item[Idx]^.Commands);
              End;
            End;
          End;
        End;
      End;
      $0009: Begin { Tab = next field, Shift+Tab = prev field }
        {$IFDEF WINDOWS}
        If IsVKDown($10) Then Begin
          If CurField > 0 Then Dec(CurField);
        End Else Begin
          If CurField < MaxField Then Inc(CurField);
        End;
        {$ELSE}
        If CurField < MaxField Then Inc(CurField);
        {$ENDIF}
      End;
      $5200: Begin { INS — insert command }
        If Menu.Item[Idx]^.Commands < MaxMenuCmds Then Begin
          If CurField >= DETAIL_FIELDS Then
            CmdIdx := CurField - DETAIL_FIELDS + 1
          Else
            CmdIdx := Menu.Item[Idx]^.Commands + 1;
          Menu.InsertCommand(Idx, CmdIdx);
          S := RunCommandPicker;
          If S <> '' Then
            Menu.Item[Idx]^.CmdData[CmdIdx]^.MenuCmd := S
          Else
            Menu.DeleteCommand(Idx, CmdIdx);
        End;
      End;
      $5300: Begin { DEL — delete command }
        If CurField >= DETAIL_FIELDS Then Begin
          CmdIdx := CurField - DETAIL_FIELDS + 1;
          If (CmdIdx >= 1) And (CmdIdx <= Menu.Item[Idx]^.Commands) Then
            Menu.DeleteCommand(Idx, CmdIdx);
        End;
      End;
      $001B: Running := False; { ESC }
      $FFFF: Begin QuitNow := True; Running := False; End; { Alt+X }
    End;
  End;
End;

{ ================================================================
  Screen 3 main loop: Menu Item Editor
  ================================================================ }

Var
  ClipItem : PtrMenuItem;  { copy/paste clipboard }

{ ================================================================
  Slash command menu (/help popup)
  ================================================================ }

Function RunSlashMenu: Char;
{ Shows a popup overlay with available commands.
  Returns the command letter (I/D/C/P) or #0 if cancelled. }
Const
  NUM_OPTS = 5;
  OptKeys : Array[1..NUM_OPTS] of Char = ('I', 'D', 'C', 'P', 'V');
  OptDesc : Array[1..NUM_OPTS] of String[30] = (
    'Insert Item',
    'Delete Item',
    'Copy Item',
    'Paste Item',
    'View Menu'
  );
Var
  Sel  : Integer;
  Code : Word;
  Ch   : Char;
  I    : Integer;
  BX1, BY1, BX2, BY2: Integer;
Begin
  Result := #0;
  Sel := 1;
  BX1 := 200; BY1 := 100; BX2 := 440; BY2 := 100 + NUM_OPTS * 18 + 30;

  Repeat
    { Draw overlay — canvas pass }
    DrawRaisedBox(BX1, BY1, BX2, BY2, CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
    DrawSeparatorH(BX1+5, BX2-5, BY1+18, CLR_BRIGHT, CLR_SHADOW);
    FlushToScreen;

    { Text pass — after FlushToScreen so text stays visible }
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
    {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(BX1 + 8, BY1 + 5, '/ Commands');

    For I := 1 to NUM_OPTS Do Begin
      If I = Sel Then Begin
        FillRect(BX1+4, BY1 + 18 + (I-1)*18 + 2, BX2-4,
                 BY1 + 18 + I*18, CLR_SELECT);
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_WARN);
      End Else Begin
        FillRect(BX1+4, BY1 + 18 + (I-1)*18 + 2, BX2-4,
                 BY1 + 18 + I*18, CLR_MENU_BG);
        {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15);
      End;
      {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(BX1 + 12, BY1 + 22 + (I-1)*18,
        OptKeys[I] + ' - ' + OptDesc[I]);
    End;

    Code := GetKey(Ch);
    Case Code Of
      $4800: If Sel > 1 Then Dec(Sel);           { Up }
      $5000: If Sel < NUM_OPTS Then Inc(Sel);     { Down }
      $000D: Begin Result := OptKeys[Sel]; Exit; End; { Enter }
      $001B: Exit;                                 { ESC }
    Else
      { Direct letter pick }
      Ch := UpCase(Ch);
      For I := 1 to NUM_OPTS Do
        If Ch = OptKeys[I] Then Begin Result := Ch; Exit; End;
    End;
  Until False;
End;

Procedure RunMenuEditor(Const MenuPath, MenuName: String);
Var
  Menu     : TMenuData;
  CurItem  : Integer;
  PageOfs  : Integer;
  VisCount : Integer;
  Running  : Boolean;
  Code     : Word;
  Ch       : Char;
  SlashCmd : Char;
  TmpMRP   : TMRPMenu;
  I        : Integer;
Begin
  SlashCmd := #0;
  Menu := TMenuData.Create;
  Try
    If EditMode = 0 Then Begin
      If Not Menu.LoadMnu(MenuPath + MenuName + '.mrp') Then Begin
        MessageBox('Error', 'Cannot load ' + MenuPath + MenuName + '.mrp');
        Exit;
      End;
    End Else Begin
      If Not Menu.LoadMnu(MenuPath + MenuName + '.mnu') Then Begin
        MessageBox('Error', 'Cannot load ' + MenuPath + MenuName + '.mnu');
        Exit;
      End;
    End;

    CurItem := 1;
    PageOfs := 0;
    VisCount := 12;
    Running := True;
    DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);

    While Running Do Begin
      SlashCmd := #0;
      Code := GetKey(Ch);

      Case Code Of
        $4800: Begin { Up }
          If CurItem > 1 Then Begin
            Dec(CurItem);
            If CurItem <= PageOfs Then PageOfs := CurItem - 1;
          End;
          DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
        End;
        $5000: Begin { Down }
          If CurItem < Menu.NumItems Then Begin
            Inc(CurItem);
            If CurItem > PageOfs + VisCount Then PageOfs := CurItem - VisCount;
          End;
          DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
        End;
        $4900: Begin { PgUp }
          Dec(CurItem, VisCount);
          If CurItem < 1 Then CurItem := 1;
          PageOfs := CurItem - 1;
          DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
        End;
        $5100: Begin { PgDn }
          Inc(CurItem, VisCount);
          If CurItem > Menu.NumItems Then CurItem := Menu.NumItems;
          If CurItem > PageOfs + VisCount Then PageOfs := CurItem - VisCount;
          DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
        End;
        $000D: Begin { Enter — edit item detail }
          If (CurItem >= 1) And (CurItem <= Menu.NumItems) Then Begin
            RunItemDetail(Menu, CurItem);
            If QuitNow Then Begin Running := False; End
            Else DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
          End;
        End;
        $FFFF: Begin { Alt+X — quit without save }
          Running := False;
        End;
        $001B: Begin { ESC — ask to save, then exit }
          If ConfirmBox('Save Changes', 'Save changes to ' + MenuName + '?') Then Begin
            If EditMode = 0 Then Begin
              { RIP mode — save as .mrp }
              If Menu.SaveMrp(MenuPath + MenuName + '.mrp') Then
                MessageBox('Saved', MenuPath + MenuName + '.mrp saved.')
              Else
                MessageBox('Error', 'Cannot save ' + MenuPath + MenuName + '.mrp');
            End Else Begin
              { ANSI mode — save as .mnu }
              If Menu.SaveMnu(MenuPath + MenuName + '.mnu') Then
                MessageBox('Saved', MenuPath + MenuName + '.mnu saved.')
              Else
                MessageBox('Error', 'Cannot save ' + MenuPath + MenuName + '.mnu');
            End;
          End;
          Running := False;
        End;
        $0109: SlashCmd := 'I'; { Ctrl+I }
        $0104: SlashCmd := 'D'; { Ctrl+D }
        $0103: SlashCmd := 'C'; { Ctrl+C }
        $0110: SlashCmd := 'P'; { Ctrl+P }
        $0116: SlashCmd := 'V'; { Ctrl+V }
      Else
        { / opens command menu }
        If Ch = '/' Then SlashCmd := RunSlashMenu
        Else SlashCmd := #0;
      End;

      { Execute slash command action }
      Case SlashCmd Of
        'V': Begin { View Menu preview }
          If EditMode = 0 Then Begin
            { RIP mode — render as 3D buttons }
            Menu.SaveMrp(MenuPath + '_preview.mrp');
            If MRP_LoadMenu(MenuPath + '_preview.mrp', TmpMRP) Then Begin
              MRP_RenderMenu(TmpMRP, 1);
              FlushToScreen;
              DrawStatusBar('RIP Preview -- press any key to return');
              GetKey(Ch);
            End Else
              MessageBox('Error', 'Cannot render menu preview.');
            SysUtils.DeleteFile(MenuPath + '_preview.mrp');
          End Else Begin
            { ANSI mode — show text items list }
            DrawBackground;
            DrawRaisedBox(20, 20, RIP_WIDTH-20, RIP_HEIGHT-20,
              CLR_MENU_BG, CLR_BRIGHT, CLR_SHADOW);
            FlushToScreen;
            {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(CLR_MENU_FG);
            {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(30, 28,
              'ANSI Preview: ' + Menu.Info.Description);
            For I := 1 to Menu.NumItems Do Begin
              If I > 20 Then Break;
              {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.SetColor(15);
              {$IFDEF UNIX}ptcgraph{$ELSE}Graph{$ENDIF}.OutTextXY(30, 40 + (I-1)*14,
                IntToStr(I) + '. ' + MRP_StripPipes(Menu.Item[I]^.Text));
            End;
            DrawStatusBar('ANSI Preview -- press any key to return');
            GetKey(Ch);
          End;
          DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
        End;
        'I': Begin { Insert }
          Menu.InsertItem(CurItem + 1);
          Inc(CurItem);
          DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
        End;
        'D': Begin { Delete }
          If (Menu.NumItems > 0) And
             ConfirmBox('Delete', 'Delete item ' + IntToStr(CurItem) + '?') Then Begin
            Menu.DeleteItem(CurItem);
            If CurItem > Menu.NumItems Then CurItem := Menu.NumItems;
            If CurItem < 1 Then CurItem := 1;
          End;
          DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
        End;
        'C': Begin { Copy }
          If (CurItem >= 1) And (CurItem <= Menu.NumItems) And
             (Menu.Item[CurItem] <> Nil) Then Begin
            If ClipItem <> Nil Then Dispose(ClipItem);
            New(ClipItem);
            ClipItem^ := Menu.Item[CurItem]^;
            MessageBox('Copied', 'Item ' + IntToStr(CurItem) + ' copied.');
          End;
          DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
        End;
        'P': Begin { Paste }
          If ClipItem <> Nil Then Begin
            Menu.InsertItem(CurItem + 1);
            Inc(CurItem);
            Menu.Item[CurItem]^.Text    := ClipItem^.Text;
            Menu.Item[CurItem]^.TextLo  := ClipItem^.TextLo;
            Menu.Item[CurItem]^.TextHi  := ClipItem^.TextHi;
            Menu.Item[CurItem]^.HotKey  := ClipItem^.HotKey;
            Menu.Item[CurItem]^.Access  := ClipItem^.Access;
            Menu.Item[CurItem]^.X       := ClipItem^.X;
            Menu.Item[CurItem]^.Y       := ClipItem^.Y;
            Menu.Item[CurItem]^.ReDraw  := ClipItem^.ReDraw;
            Menu.Item[CurItem]^.Timer   := ClipItem^.Timer;
          End Else
            MessageBox('Paste', 'Clipboard empty - Copy first.');
          DrawMenuEditor(Menu, CurItem, PageOfs, MenuName);
        End;
      End;
    End;
  Finally
    Menu.Free;
  End;
End;

{ ================================================================
  Demo menu creator (same as text-mode makemenu)
  ================================================================ }

Procedure AddMenuItem(Menu: TMenuData; Const AText, AHotKey, ACmd, AData: String;
  AX, AY: Byte);
Var N: Integer;
Begin
  N := Menu.NumItems + 1;
  Menu.InsertItem(N);
  Menu.Item[N]^.Text := AText;
  Menu.Item[N]^.HotKey := AHotKey;
  Menu.Item[N]^.X := AX;
  Menu.Item[N]^.Y := AY;
  If ACmd <> '' Then Begin
    Menu.InsertCommand(N, 1);
    Menu.Item[N]^.CmdData[1]^.MenuCmd := ACmd;
    Menu.Item[N]^.CmdData[1]^.Data := AData;
  End;
End;

Procedure CreateDemo(Const BaseName: String);
Var Menu: TMenuData;
Begin
  Menu := TMenuData.Create;
  Try
    Menu.Info.Description := 'Main Menu';
    AddMenuItem(Menu, 'File Areas',     'F', 'MN', 'file',     5, 33);
    AddMenuItem(Menu, 'Message Areas',  'M', 'MN', 'msg',      5, 41);
    AddMenuItem(Menu, 'Email',          'E', 'MN', 'email',    5, 49);
    AddMenuItem(Menu, 'Settings',       'S', 'MN', 'settings', 5, 57);
    AddMenuItem(Menu, 'Who Is Online',  'W', 'WO', '',         5, 65);
    AddMenuItem(Menu, 'Page Sysop',     'P', 'PC', '',         5, 73);
    AddMenuItem(Menu, 'Goodbye',        'G', 'GX', '',         5, 81);

    If Menu.SaveMnu(BaseName + '.mnu') Then
      WriteLn('Created: ', BaseName, '.mnu (', Menu.NumItems, ' items)');
    If Menu.SaveMrp(BaseName + '.mrp') Then
      WriteLn('Created: ', BaseName, '.mrp');
  Finally
    Menu.Free;
  End;
End;

{ ================================================================
  Help
  ================================================================ }

Procedure ShowHelp;
Begin
  WriteLn('makemenu_rip v', '0.1.0', ' - Mystic BBS Menu Editor (RIP Graphics Mode)');
  WriteLn('');
  WriteLn('Usage:');
  WriteLn('  makemenu_rip                    Graphics mode editor (640x350)');
  WriteLn('  makemenu_rip -demo <name>       Create demo menu files');
  WriteLn('  makemenu_rip -?                 This help');
  WriteLn('');
  WriteLn('Reads mystic.dat for paths, theme.dat for themes.');
  WriteLn('Widget concept inspired by JMedia v2.0');
  WriteLn('the crew 4free');
End;

{ ================================================================
  Main
  ================================================================ }

Var
  ThemeIdx  : Integer;
  MenuPath  : String;
  MenuName  : String;
Begin
  ClipItem := Nil;
  QuitNow := False;

  { CLI: -demo or -? }
  If ParamCount > 0 Then Begin
    If (ParamStr(1) = '-?') Or (ParamStr(1) = '-h') Then Begin
      ShowHelp; Halt(0);
    End;
    If ParamStr(1) = '-demo' Then Begin
      If ParamCount >= 2 Then CreateDemo(ParamStr(2))
      Else CreateDemo('main');
      Halt(0);
    End;
  End;

  { Load BBS config }
  HasConfig := LoadConfig;
  If Not HasConfig Then Begin
    WriteLn('ERROR: Cannot read mystic.dat');
    WriteLn('Run from Mystic BBS root directory.');
    Halt(1);
  End;

  { Init graphics — use VGA 640x480 (EGA 640x350 unsupported on Win64 Graph) }
  { RIP canvas is 640x350 internally; extra rows stay black }
  Gd := VGA;
  Gm := VGAHi;
  InitGraph(Gd, Gm, '');
  If GraphResult <> grOk Then Begin
    WriteLn('Graphics init failed: ', GraphErrorMsg(GraphResult));
    Halt(1);
  End;

  InitCanvas;
  EnterGraphics;

  { Main flow: Mode -> Theme -> Menu List -> Menu Editor }
  EditMode := RunModeSelector;
  If (EditMode < 0) Or QuitNow Then Begin
    CloseGraph;
    {$IFDEF WINDOWS}WinExitProcess(0);{$ELSE}Halt(0);{$ENDIF}
  End;

  ThemeIdx := RunThemeSelector;

  If (ThemeIdx >= 0) And (Not QuitNow) Then Begin
    MenuPath := Themes[ThemeIdx].MenuPath;
    If MenuPath = '' Then MenuPath := 'menus\';
    { Ensure trailing separator }
    If (Length(MenuPath) > 0) And (MenuPath[Length(MenuPath)] <> '\') And
       (MenuPath[Length(MenuPath)] <> '/') Then
      MenuPath := MenuPath + '\';

    MenuName := RunMenuList(MenuPath);

    If (MenuName <> '') And (Not QuitNow) Then
      RunMenuEditor(MenuPath, MenuName);
  End;

  { Cleanup }
  If ClipItem <> Nil Then Dispose(ClipItem);
  CloseGraph;
  {$IFDEF WINDOWS}
  WinExitProcess(0);  { kill Graph window thread + console }
  {$ELSE}
  Halt(0);
  {$ENDIF}
End.
