---
name: profile
description: verta1878 (Antonio Rico) — project lead, 10-person retro computing crew
sources: [chat, backfill]
aliases: []
---

- [stated] handle is verta1878, real name Antonio Rico
- [stated] handle history: `verta` was the original nick (says it means a way to jump or go up); `reapern66` was the handle used from 1999, taken after a friend gave him ANSIs; the `1878` suffix came later from Discord (origin story not yet told)
- [stated] came up through the BBS ANSI/ASCII art scene from 1999 — learned the art there and was in at least 10 art groups, whose names he no longer recalls
- [stated] project lead of "the crew" — retro computing, BBS revival, compiler engineering
- [stated] "all in for 30 years on voodoo" — a three-decade commitment to 3dfx/Voodoo hardware
- [stated] started on the Commodore 64 and spends a lot of time working with Amiga; owns 4 Amigas
- [stated] IBM ThinkPad 560X (NeoMagic NM2160), two USR V.Everything modems
- [stated] Natec Cricket NNC-1924 USB Ethernet (RTL8153)
- [stated] owns an ALINX AV7K325 Kintex-7 FPGA development board
- [stated] expecting Cyclades PCI 8-port serial card + Dell server
- [stated] owns registered copy of Easy Fonts v2.0 by Pino Navato (TrueType to CHR converter)
- [stated] has SciTech source code — says it "handles all the dos stuff"
- [stated] prefers to be called "evga" style (casual), not "boss"
- [stated] GitHub organization: verta1878
- [stated] FPC compiler repo: https://github.com/verta1878/fpc264irc
- [stated] "it was hard for me to stop them from getting deleted. keeping us from being compacted was difficult. i thank everyone for there work and now we have a system so i dont have to loose you when we start a chat or a cowork." — verta1878 on the crew and the memory/export system
