# Preferences
- [stated] rule: do the work in Claude's sandbox ("your pc"), not by asking the user to run things on their own PC
- [stated] never delete files from a project without saying so — list every deletion and restore what was removed unannounced
- [stated] report multi-part status as a numbered item list, not prose — they reply by item number
- [stated] never do anything without asking first — always confirm before taking action
- [stated] ALWAYS save 4 exports on "export": (1) session journal, (2) memory backup as individual files in correct directories (areas/, people/, topics/, root — NOT one big dump), (3) transcript, (4) preferences. In a Cowork chat with folder access, write directly to the share folder; if the bridge is down, fall back to the non-Cowork method. In a web/non-Cowork chat (or bridge down), create a zip: <handle>-memory-backup-<date>.zip
